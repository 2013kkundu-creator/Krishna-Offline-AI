plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.krishna.offlineai"; compileSdk = 36
    defaultConfig { applicationId = "com.krishna.offlineai"; minSdk = 33; targetSdk = 36; versionCode = 5; versionName = "0.5.0" }
    buildFeatures { viewBinding = false }
    packaging { jniLibs.useLegacyPackaging = true }
}

// When the official llama.android :lib module is copied into this project,
// add: implementation(project(":lib"))
