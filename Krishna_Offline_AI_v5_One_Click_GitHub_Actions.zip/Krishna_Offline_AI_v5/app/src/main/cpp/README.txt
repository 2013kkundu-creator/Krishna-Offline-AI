Reserved for optional project-specific JNI glue. The official llama.cpp Android binding should provide the inference engine.
