package com.krishna.offlineai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var log: TextView
    private var modelUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        val title = TextView(this).apply { text = "Krishna Offline AI"; textSize = 24f; gravity = Gravity.CENTER; setPadding(0,0,0,18) }
        val status = TextView(this).apply { text = "Engine: waiting for llama.cpp\nModel: not selected"; textSize = 14f }
        val pick = Button(this).apply { text = "Select GGUF Model" }
        log = TextView(this).apply { text = "\nReady. Select a .gguf model."; textSize = 16f; setPadding(0,18,0,18) }
        val input = EditText(this).apply { hint = "Ask something..."; minLines = 2 }
        val send = Button(this).apply { text = "Send"; isEnabled = false }

        pick.setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "application/octet-stream"; addCategory(Intent.CATEGORY_OPENABLE)
            }, 10)
        }
        send.setOnClickListener {
            log.append("\n\nYou: ${input.text}")
            log.append("\nAI: llama.cpp engine is not connected yet. Add official :lib module to enable inference.")
            input.text.clear()
        }
        root.addView(title); root.addView(status); root.addView(pick); root.addView(log)
        root.addView(input, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(send)
        setContentView(root)

        // This flag becomes true when the real engine adapter is wired in.
        send.isEnabled = false
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) {
            modelUri = data?.data
            log.text = "Selected model:\n$modelUri\n\nNext: copy to app-private storage and load through AiChat/InferenceEngine."
        }
    }
}
