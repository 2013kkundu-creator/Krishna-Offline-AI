pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }
rootProject.name = "KrishnaOfflineAI"
include(":app")
// Real llama.cpp Android binding can be added as :lib from official examples/llama.android.
