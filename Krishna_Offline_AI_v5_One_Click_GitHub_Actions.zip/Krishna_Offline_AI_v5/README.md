# Krishna Offline AI v5

Android offline-AI project for arm64 phones.

## One-click build

Use `.github/workflows/build-apk.yml` in GitHub Actions. It downloads the official `ggml-org/llama.cpp` source at build time and compiles the official Android `lib` module, then builds the APK.

See `ONE_CLICK_BUILD.md` for exact steps.

## Current status

- Android app structure: ready
- GGUF model picker: ready
- Official llama.cpp Android native module: injected during CI build
- arm64-v8a target: configured by the official module
- Final inference UI adapter: still to be wired to `AiChat`/`InferenceEngine`

Do not add a random prebuilt `.so`; the workflow intentionally builds the official source from source.
