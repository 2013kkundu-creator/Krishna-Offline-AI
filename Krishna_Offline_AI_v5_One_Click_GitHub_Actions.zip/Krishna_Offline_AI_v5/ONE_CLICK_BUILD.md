# One-click APK build

This project is configured to fetch the **official ggml-org/llama.cpp** Android library during the GitHub Actions build, instead of storing a fake or incomplete native library in the ZIP.

## Build on GitHub

1. Create a GitHub repository and upload this entire project.
2. Open **Actions**.
3. Select **Build Krishna Offline AI APK**.
4. Click **Run workflow**.
5. Leave `llama_ref` as `master` unless you need a specific tag/commit.
6. Wait for the workflow to finish.
7. Open the completed workflow run → **Artifacts** → download `Krishna-Offline-AI-Release`.

The workflow clones the official llama.cpp repository, copies its `examples/llama.android/lib` module into the project, installs Android SDK/NDK/CMake, and builds the Android APK. The native library is compiled for the Android ABIs configured by the official module; the primary phone target here is `arm64-v8a`.

## Important

This workflow builds the real native llama.cpp library. The current Krishna UI still needs the final Kotlin adapter wiring to call `AiChat`/`InferenceEngine` and stream generated tokens into the chat window. The official Android binding exposes that flow.
