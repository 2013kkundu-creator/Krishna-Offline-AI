#!/usr/bin/env bash
set -euo pipefail
REF="${1:-master}"
rm -rf _llama_cpp lib gradle/wrapper gradle/libs.versions.toml
mkdir -p gradle
git clone --depth 1 --branch "$REF" https://github.com/ggml-org/llama.cpp.git _llama_cpp
cp -a _llama_cpp/examples/llama.android/lib ./lib
cp _llama_cpp/examples/llama.android/gradle/libs.versions.toml gradle/libs.versions.toml
cp _llama_cpp/examples/llama.android/gradlew ./gradlew
cp _llama_cpp/examples/llama.android/gradlew.bat ./gradlew.bat
cp -a _llama_cpp/examples/llama.android/gradle/wrapper gradle/
chmod +x gradlew
python3 - <<'PY'
from pathlib import Path
p=Path('settings.gradle.kts'); s=p.read_text()
if 'include(":lib")' not in s: s=s.replace('include(":app")','include(":app", ":lib")')
p.write_text(s)
p=Path('app/build.gradle.kts'); s=p.read_text()
if 'implementation(project(":lib"))' not in s: s+='\n\ndependencies { implementation(project(":lib")) }\n'
p.write_text(s)
PY
./gradlew :app:assembleRelease --no-daemon
